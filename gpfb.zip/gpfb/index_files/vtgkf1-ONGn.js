/*!CK:905173289!*//*1399254413,178142239*/

if (self.CavalryLogger) { CavalryLogger.start_js(["825gI"]); }

__d("BroadcastRequestParam",[],function(a,b,c,d,e,f){e.exports={ANSWER_IDS:"answer_ids",COMMENT_TOKEN:"comment_token",COMPOSER_TOKEN_IDS:"composer_token_ids",DESCRIPTION_DOM_ID:"description_dom_id",DOM_ID:"dom_id",ENTITY_TITLE:"entity_title",ENTITY_TOKEN:"entity_token",HAS_VIEWER_VOTED:"has_viewer_voted",QUERY:"q",STATUS_ID:"status_id",SUGGESTION_CARD_ID:"suggestion_card_id",SUGGESTION_ID:"suggestion_id",TARGET_ID:"target_id",VOTE_ACTION:"vote_action",EXISTING_IDS:"existing_ids",VALUE:"value"};});