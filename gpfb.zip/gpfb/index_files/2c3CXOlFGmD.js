/*!CK:3364739018!*//*1399988269,178134573*/

if (self.CavalryLogger) { CavalryLogger.start_js(["Smkxu"]); }

__d("EntstreamStoryAttachment",["CSS","Event"],function(a,b,c,d,e,f,g,h){function i(j,k){"use strict";this.link=j;this.attachment=k;g.hide(this.attachment);h.listen(this.link,'click',this.showAttachment.bind(this));}i.prototype.showAttachment=function(){"use strict";g.hide(this.link);g.show(this.attachment);};e.exports=i;});