#!/bin/sh

dmesg | grep " T sys_" | sort | uniq > dmesg.out

cat /proc/kallsyms | grep " T sys_" | sort | uniq > kallsyms.out

cat /boot/System.map | grep " T sys_" | sort | uniq > system_map.out

diff -u dmesg.out system_map.out > kern-map.diff
diff -u dmesg.out kallsyms.out > kern-syms.diff
diff -u system_map.out kallsyms.out > map-syms.diff
