#include <stdio.h>

int main(int argc, char **argv)
{
       
}

/* Cut and paste output from dmesg here */
