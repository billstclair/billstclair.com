/*
 * $Id: Appearance.java,v 1.1 2003/01/24 21:42:50 wws Exp $
 * An interface to control the appearance of a Physob
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.io.Serializable;

/**
 * An interface to decide on the appearance of a Physob.
 * It has a Drawing for each of the four directions from which it
 * can be viewed.
 * SimpleAppearance is the simplest implementation.
 */
public interface Appearance extends Serializable {

  public Drawing getFrontView(Physob ob);
  public Drawing getBackView(Physob ob);
  public Drawing getLeftView(Physob ob);
  public Drawing getRightView(Physob ob);
}
