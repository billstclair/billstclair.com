/*
 * $Id: WallHugger.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A behavior that walks around hugging the wall.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.robots;

import java.awt.Point;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;
import jmaze.MazeModel;
import jmaze.behavior.PauseBehavior;


/**
 * A behavior that walks around hugging the wall
 */
public class WallHugger extends Robot {

  /**
   * Do the normal Robot thing when constructed with no arguments
   */
  public WallHugger() {
    super();
  }

  /**
   * Make a wall hugger that moves every "delay" clock ticks.
   */
  public WallHugger(int delay) {
    super(delay);
  }

  public Action doSomething(Physob ob, MazeModel maze, int x, int y, int dir) {
    if (!maze.forwardWallP(x, y, dir)) return FORWARD;
    if (!maze.leftWallP(x, y, dir)) return LEFT;
    return RIGHT;
  }
}
