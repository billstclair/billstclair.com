/*
 * $Id: MissileBehavior.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A behavior that walks around randomly turning
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.robots;

import java.awt.Point;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;
import jmaze.MazeModel;
import jmaze.behavior.PauseBehavior;

/**
 * The missile
 */
public class MissileBehavior extends Robot {

  protected Physob owner;

  /**
   * Constructor for serialization.
   * Use one of the other constructors in code.
   */
  public MissileBehavior() {
  }

  /**
   * A missile defaults to a delay of zero. Bloody fast.
   */
  public MissileBehavior(Physob owner) {
    this(owner, 0);
  }

  /**
   * Make a missile that moves every "delay" clock ticks.
   */
  public MissileBehavior(Physob owner, int delay) {
    super(delay);
    this.owner = owner;
  }

  public Physob getOwner() {
    return owner;
  }

  public Action doSomething(Physob ob, MazeModel maze, int x, int y, int dir) {
    if (maze.isCellShared(ob)) return explode(ob, maze, x, y);
    else if (maze.forwardWallP(x, y, dir)) return DIE;
    else {
      x += maze.deltaX(dir);
      y += maze.deltaY(dir);
      if (maze.isCellOccupied(x, y)) {
        // This code is here to prevent moving through a missile.
        return explode(ob, maze, x, y);
      } else return FORWARD;
    }
  }

  protected Action explode(Physob ob, MazeModel maze, int x, int y) {
    Physob[] obs = maze.getOccupants(x, y);
    for (int i=0; i<obs.length; i++) {
      Physob o = obs[i];
      if ((o != ob) && (o != owner)) o.kill(owner);
    }
    return DIE;
  }
}
