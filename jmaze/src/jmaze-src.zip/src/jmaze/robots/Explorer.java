/*
 * $Id: Explorer.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A behavior that explores randomly
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.robots;

import java.awt.Point;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;
import jmaze.MazeModel;
import jmaze.behavior.PauseBehavior;


/**
 * A behavior that explores randomly.
 * It only turns if there's somewhere to go, then goes there.
 * It only turns around if it finds a dead end.
 */
public class Explorer extends Robot {

  Behavior pauseBehavior;
  boolean turnedLastTime = false;
  boolean turningAround = false;

  /**
   * By default, we wait a second between moves.
   */
  public Explorer() {
    super();
  }

  /**
   * Make a wall hugger that moves every "delay" clock ticks.
   */
  public Explorer(int delay) {
    super(delay);
  }

  public Action doSomething(Physob ob, MazeModel maze, int x, int y, int dir) {
    if (turnedLastTime) {
      turnedLastTime = false;
      return FORWARD;
    }
    if (turningAround) {
      turningAround = false;
      return RIGHT;
    }
    boolean f = !maze.forwardWallP(x, y, dir);
    boolean l = !maze.leftWallP(x, y, dir);
    boolean r = !maze.rightWallP(x, y, dir);
    int cnt = 0;
    if (f) cnt++;
    if (l) cnt++;
    if (r) cnt++;
    if (cnt == 0) {
      turningAround = true;
      return RIGHT;
    }
    int choice = (int)(Math.random() * cnt);
    if (choice == cnt) choice--;
    Action res = RIGHT;
    if (choice == 0) {
      if (f) res = FORWARD;
      if (l) res = LEFT;
    } else if (choice == 1) {
      if (f) {
        if (l) res = LEFT;
      }
    }
    if (res != FORWARD) turnedLastTime = true;
    return res;
  }
}
