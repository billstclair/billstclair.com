/*
 * $Id: Drunk.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A behavior that walks around randomly turning
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.robots;

import java.awt.Point;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;
import jmaze.MazeModel;
import jmaze.behavior.PauseBehavior;

/**
 * A behavior that walks around hugging the wall
 */
public class Drunk extends Robot {

  /**
   * Do the normal Robot thing when constructed with no arguments
   */
  public Drunk() {
    super();
  }

  /**
   * Make a wall hugger that moves every "delay" clock ticks.
   */
  public Drunk(int delay) {
    super(delay);
  }

  public Action doSomething(Physob ob, MazeModel maze, int x, int y, int dir) {
    boolean canForward = !maze.forwardWallP(x, y, dir);
    int choice = (int)(Math.random() * (canForward ? 5 : 2));
    if (choice == 0) return LEFT;
    if ((choice == 1) || !canForward) return RIGHT;
    return FORWARD;
  }
}
