/*
 * $Id: Robot.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * The base behavior for robots
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.robots;

import java.awt.Point;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;
import jmaze.MazeModel;
import jmaze.behavior.PauseBehavior;

/**
 * The base Behavior for all robots
 */
public abstract class Robot implements Behavior {

  Behavior pauseBehavior;

  /**
   * By default, we wait a second between moves.
   */
  public Robot() {
    this(10);
  }

  /**
   * Make a wall hugger that moves every "delay" clock ticks.
   */
  public Robot(int delay) {
    if (delay > 0) pauseBehavior = new PauseBehavior(delay, this);
  }

  public Action doSomething(Physob ob) {
    if (pauseBehavior != null) ob.addBehavior(pauseBehavior);
    else ob.addBehavior(this);
    Point p = ob.position;    
    return doSomething(ob, ob.maze, p.x, p.y, ob.direction);
  }

  public abstract Action doSomething(Physob ob, MazeModel maze,
                                     int x, int y, int direction);
}
