/*
 * $Id: MazeApplet.java,v 1.7 2003/01/26 14:32:21 wws Exp $
 * An applet to display a maze.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Component;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.awt.BorderLayout;

public class MazeApplet extends Applet {

  protected MazeModel model;

  public String getAppletInfo() {
    return "Copyright 2003, Bill St. Clair, bill@billstclair.com";
  }

  Component panel;
  Engine engine;

  public void init() {
    // Eventually, this will take parameters telling it where to
    // load the model.
    model = new MazeModel(true);
    model.addTestGuys();
    setBackground(Color.white);
    panel = getPanel(model);
    model.setPaintComponent(panel);
    addKeyListener(model);
  }

  public void start() {
    engine = new Engine(model);
    requestFocus();
  }

  public void stop() {
    engine.quit();
  }

  public void destroy() {
    // Nothing to do
  }

  public void paint(Graphics g) {
    if (panel == this) model.paint(g, getSize());
    else super.paint(g);
  }

  /**
   * Get a MazePanel, if we can.
   * repaint() does the right thing in old JVM's, but
   * if you just use that in a new VM, you end up with
   * a long delay to the actual repaint. In a new VM,
   * we use MazePanel's paintImmediately() call.
   * Bottom line, this applet works in both Microsoft's VM
   * and Java 1.4.1, and likley everything in between.
   */
  public Component getPanel(MazeModel model) {
    try {
      Graphics g = getGraphics();
      Class.forName("javax.swing.JPanel");
      Class c = Class.forName("jmaze.MazePanel");
      Constructor con = c.getConstructor(new Class[] {MazeModel.class});
      Component res = (Component)con.newInstance(new Object[] {model});
      setLayout(new BorderLayout());
      add(res, BorderLayout.CENTER);
      return res;
    } catch (Throwable e) {
      return this;
    }
  }

}
