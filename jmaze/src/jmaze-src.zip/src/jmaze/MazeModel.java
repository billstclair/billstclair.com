/*
 * $Id: MazeModel.java,v 1.8 2003/01/26 16:18:49 wws Exp $
 * Model and display code for the jmaze application
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 * 01/26/03 wws Disallow moving onto another player, unless
 *              he or you is a "ghost".
 */

package jmaze;

import java.io.Serializable;
import java.awt.Point;
import java.awt.Graphics;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.util.Vector;
import jmaze.behavior.ShootWrapper;
import jmaze.robots.WallHugger;
import jmaze.robots.Drunk;
import jmaze.robots.Explorer;
import jmaze.Robot;

/**
 * The model and display code for a jmaze.
 */
public class MazeModel implements KeyListener, Serializable {

  /**
   * A two-dimensional array of the horizontal wall segments.
   */
  protected boolean[][] hWalls;

  /**
   * A two-dimensional array of the vertical wall segments.
   */
  protected boolean[][] vWalls;

  /**
   * A Vector to hold the Physobs in the Maze
   */
  protected Vector occupants = new Vector();

  /**
   * An with a Vector of Physobs at each position
   */
  protected Vector[][] occupantCells;

  /**
   * The width of the maze
   */
  protected int width;

  /**
   * The height of the maze
   */
  protected int height;

  /**
   * Cached sizes
   */
  protected int[] cachedSizes;

  /**
   * Cached total size for sizes
   */
  protected int cachedSize = -1;

  /**
   * The Engine that's running us
   */
  protected Engine engine;

  /**
   * The object that is the eye in the maze on this machine
   */
  protected Physob eye;

  /**
   * UP means the first index is increasing and the second is constant
   */
  public static final int UP = 0;

  /**
   * DOWN means the first index is decreasing and the second is constant
   */
  public static final int DOWN = 1;

  /**
   * RIGHT means the first index is constant and the second is increasing
   */
  public static final int RIGHT = 2;

  /**
   * UP means the first index is constant and the second is decreasing
   */
  public static final int LEFT = 3;

  /**
   * The current position of the eye in the maze
   */
  protected Point position = new Point(1, 1);

  /**
   * The direction the eye is looking
   */
  protected int direction = RIGHT;

  /**
   * The component to repaint() after a keystroke
   */
  protected Component paintComponent;

  /**
   * The default maze. 
   * I'll make a better one after writing a GUI designer.
   * Note that UP, DOWN, LEFT, and RIGHT are relative to
   * the way this text appears on the screen. The
   * upper-left corner is (1,1) increasing to the right and down
   */                            
  protected static String[] defaultRows =
    new String[] {"  _   _ _   _ _ _  |",
                  "_  | |  _   _ _ _  |",
                  "  _| | |   |   | | |",
                  " | | | | | | | | | |",
                  " | | | | |_| | | | |",
                  "   | | |_ _  | | | |",
                  " | | |_ _  |_|   | |",
                  " | |  _  |_ _ _| | |",
                  " |_ _|_ _ _   _ _| |",
                  "_ _ _ _ _ _ _ _ _ _|"};
                                    
  /**
   * Create a new MazeModel with no maze.
   * This method is for serialization.
   */
  public MazeModel() {
  }

  /**
   * Create a new MazeModel. Initialize with the default maze
   * if defaultMaze is true
   */
  public MazeModel(boolean defaultMaze) {
    this((String[])(defaultMaze ? defaultRows : null));
  }

  /**
   * Create a new maze model with the given rows.
   * @param rows See setWalls(String[] rows)
   */
  public MazeModel(String[] rows) {
    if (rows != null) setWalls(rows);
  }

  /**
   * Create a new MazeModel with the given walls arrays.
   * @param hWalls The new value for the horizontal walls array
   * @param vWalls The new value for the vertical walls array
   */
  public MazeModel(boolean [][] hWalls, boolean[][]vWalls) {
    setWalls(hWalls, vWalls);
  }

  /**
   * Return the horizontal walls array.
   */
  public boolean[][] getHWalls() {
    return hWalls;
  }

  /**
   * Return the vertical walls array.
   */
  public boolean[][] getVWalls() {
    return vWalls;
  }

  /**
   * Set the walls arrays
   * @param hWalls The new horizontal walls array.
   * @param vWalls The new vertical walls array.
   */
  public void setWalls(boolean[][] hWalls, boolean[][] vWalls) {
    int height = hWalls.length;
    int width = hWalls[0].length;
    if ((vWalls.length != height) || (hWalls[0].length != width)) {
      throw new IllegalArgumentException("hWalls incompatible with vWalls");
    }
    this.hWalls = hWalls;
    this.vWalls = vWalls;
    this.occupantCells = new Vector[height][width];
    this.height = height - 1;
    this.width = width - 1;
  }

  /**
   * Set the walls from a string array with a human-readable
   * representation.
   * Each row should containing alternating horizontal and vertical
   * walls. A space means no wall. Anything else means a wall.
   * It is easiest to read to use "_" for a horizontal wall and
   * *|" for a vertical wall.
   * @param rows The array of alternating h & v strings
   */
  public void setWalls(String[] rows) {
    int height = rows.length;
    int len = rows[0].length();
    int width = len / 2;
    if (len != (width * 2)) {
      throw new IllegalArgumentException("Non-even row length");
    }
    for (int i=1; i<height; i++) {
      if (rows[i].length() != len) {
        throw new IllegalArgumentException("Inconsistent row length");
      }
    }
    boolean[][] hWalls = new boolean[height+1][width+1];
    boolean[][] vWalls = new boolean[height+1][width+1];

    /* initialize the top edge */
    for (int x=0; x<= height; x++) {
      hWalls[0][x] = true;
    }
    /* initialize the left edge */
    for (int y=0; y<= height; y++) {
      vWalls[y][0] = true;
    }

    /* initialize the rest of the walls */
    for (int y=1; y<=height; y++) {
      boolean[] hWall = hWalls[y];
      boolean[] vWall = vWalls[y];
      String row = rows[y-1];
      int idx = 0;
      for (int x=1; x<=width; x++) {
        hWall[x] = (row.charAt(idx++) != ' ');
        vWall[x] = (row.charAt(idx++) != ' ');
      }
    }
    setWalls(hWalls, vWalls);
  }

  /** The change in the X (second) coordinate for one of the directions.
   * @param direction UP, DOWN, LEFT, or RIGHT
   */
  public int deltaX(int direction) {
    if ((direction == UP) || (direction == DOWN)) return 0;
    if (direction == RIGHT) return 1;
    return -1;
  }

  /** The change in the Y (first) coordinate for one of the directions.
   * @param direction UP, DOWN, LEFT, or RIGHT
   */
  public int deltaY(int direction) {
    if ((direction == LEFT) || (direction == RIGHT)) return 0;
    if (direction == DOWN) return 1;
    return -1;
  }

  /**
   * Return the value of the left-hand wall from a given position and direction
   */
  public boolean leftWallP(int x, int y, int direction) {
    if (direction == UP) return vWalls[y][x-1];
    if (direction == DOWN) return vWalls[y][x];
    if (direction == LEFT) return hWalls[y][x];
    return hWalls[y-1][x];
  }

  /**
   * Return the value of the right-hand wall from a given position and direction
   */
  public boolean rightWallP(int x, int y, int direction) {
    if (direction == UP) return vWalls[y][x];
    if (direction == DOWN) return vWalls[y][x-1];
    if (direction == LEFT) return hWalls[y-1][x];
    return hWalls[y][x];
  }

  /**
   * Return the value of the wall in front of you from a given position and direction
   */
  public boolean forwardWallP(int x, int y, int direction) {
    if (direction == UP) return hWalls[y-1][x];
    if (direction == DOWN) return hWalls[y][x];
    if (direction == LEFT) return vWalls[y][x-1];
    return vWalls[y][x];
  }

  /**
   * Return the direction to the left of the one given
   */
  public int leftDirection(int direction) {
    if (direction == UP) return LEFT;
    if (direction == LEFT) return DOWN;
    if (direction == DOWN) return RIGHT;
    return UP;
  }

  /**
   * Return the direction to the right of the one given
   */
  public int rightDirection(int direction) {
    if (direction == UP) return RIGHT;
    if (direction == LEFT) return UP;
    if (direction == DOWN) return LEFT;
    return DOWN;
  }

  /**
   * Return the direction turned around from the given one.
   */
  public int otherDirection(int direction) {
    if (direction == UP) return DOWN;
    if (direction == LEFT) return RIGHT;
    if (direction == DOWN) return UP;
    return LEFT;
  }

  /**
   * Move a point forward in the maze. Will not move into an occupied cell.
   * @param point The point to move
   * @param direction The direction to move
   * @returns true if the point wasn't already up against the wall
   */
  public boolean movePointForward(Point point, int direction) {
    return movePointForward(point, direction, false);
  }

  /**
   * Move a point forward in the maze. Will not move into an occupied cell
   * unless ignoreCollisions is true
   * @param point The point to move
   * @param direction The direction to move
   * @param ignoreCollisions 
   * @returns true if the point was actually moved (wasn't
   *          against a wall or another character)
   */
  public boolean movePointForward(Point point, int direction,
                                  boolean ignoreCollisions) {
    int x = point.x;
    int y = point.y;
    if (forwardWallP(x, y, direction)) return false;
    int dx = deltaX(direction);
    int dy = deltaY(direction);
    if (!ignoreCollisions) {
      Vector v = occupantCells[y+dy][x+dx];
      if (v != null) {
        for (int i=0; i<v.size(); i++) {
          Physob ob = (Physob)v.elementAt(i);
          if (!ob.ghost) return false;
        }
      }
    }
    move(point, deltaX(direction), deltaY(direction));
    return true;
  }

  /**
   * Move a point backward in the maze.
   * @param point The point to move
   * @param direction The forward direction
   * @returns true if the point wasn't already up against the wall
   */
  public boolean movePointBackward(Point point, int direction) {
    int back = otherDirection(direction);
    if (forwardWallP(point.x, point.y, back)) return false;
    move(point, deltaX(back), deltaY(back));
    return true;
  }

  /**
   * Draw the maze from its current position and direction
   */
  public void draw(Graphics g, Point ul, int size) {
    if (eye != null) {
      position.x = eye.position.x;
      position.y = eye.position.y;
      direction = eye.direction;
    }
    draw(g, ul, size, position, direction);
  }

  protected void cacheSizes(int size) {
    if (cachedSize == size) return;
    int max = Math.max(width, height);
    int count = max + 1;
    cachedSizes = new int[count];
    cachedSizes[0] = size;
    double s = (double)size;
    double ms = s / 4;
    double dist = (double)max;
    double l = dist * ms / (s - ms);
    for (int n = 1; n<count; n++) {
      cachedSizes[n] = (int)Math.round(l * s / (l + (double)n));
    }
    cachedSize = size;
  }

  protected static Point origin = new Point(1, 1);

  /**
   * Call this from the paint() method of a Component to
   * draw the maze in that component.
   */
  public void paint(Graphics g, Dimension size) {
    int w = size.width;
    int h = size.height;
    int s = Math.min(w, h);
    int x = 0;
    int y = 0;
    draw(g, origin, s-2);
    g.drawLine(0, 0, s-1, 0);
    g.drawLine(s-1, 0, s-1, s);
    g.drawLine(s-1, s-1, 0, s-1);
    g.drawLine(0, s-1, 0, 0);
    g.drawString("" + position.x + ", " + position.y, s - 70, h - 20);
    if (notification != null) {
      g.drawString(notification, 40, h - 20);
    }
  }

  /**
   * Draw the maze viewed from the given point and direction
   * @param g The Graphics object on which to do the drawing.
   * @param ul The coordinate of the upper-left-hand edge of the drawing area
   * @param lr The coordinate of the lower-right-hand edge of the drawing area
   * @param position The position in the maze of the eye
   * @param direction The direction the eye is pointing
   */
  public synchronized void draw(Graphics g, Point ul, int size, Point position, int direction) {
    cacheSizes(size);
    int x = position.x;
    int y = position.y;
    int dx = deltaX(direction);
    int dy = deltaY(direction);
    int n = 1;
    int h = ul.x;
    int v = ul.y;
    g.clearRect(h, v, h+size, v+size);
    while (true) {
      if ((x <= 0) || (x > width) || (y <= 0) || (y > height)) break;
      int newSize = cachedSizes[n];
      int d = (size - newSize) / 2;
      int newh = h + d;
      int newv = v + d;
      //System.out.println("x: " + x + ", y: " + y + ", h: " + h + ", v: " + v +
      //                   ", newSize: " + newSize + ", newh: " + newh +
      //                   ", newv: " + newv);
      boolean newleftp = leftWallP(x, y, direction);
      boolean newrightp = rightWallP(x, y, direction);
      boolean forwardp = forwardWallP(x, y, direction);
      if (newleftp) {
        line(g, h, v, newh, newv);
        line(g, h, v+size, newh, newv+newSize);
        if (forwardp) line(g, newh, newv, newh, newv+newSize);
      } else {
        // Assuming here that all halls are one grid wide
        if (n > 1) line(g, h, v, h, v+size);
        if (!forwardp) line(g, newh, newv, newh, newv+newSize);
        int leftDir = leftDirection(direction);
        int leftx = x + deltaX(leftDir);
        int lefty = y + deltaY(leftDir);
        // The commented out code is correct, but doesn't look right
        // Better to avoid parallel halls with only an edge-on wall
        // between them.
        if (true /* forwardWallP(leftx, lefty, direction) */) {
          line(g, newh, newv, h, newv);
          line(g, newh, newv+newSize, h, newv+newSize);
        }
      }
      if (newrightp) {
        line(g, h+size, v, newh+newSize, newv);
        line(g, h+size, v+size, newh+newSize, newv+newSize);
        if (forwardp) line(g, newh+newSize, newv, newh+newSize, newv+newSize);
      } else {
        // Assuming here that all halls are one grid wide
        if (n > 1) line(g, h+size, v, h+size, v+size);
        if (!forwardp) line(g, newh+newSize, newv, newh+newSize, newv+newSize);
        int rightDir = rightDirection(direction);
        int rightx = x + deltaX(rightDir);
        int righty = y + deltaY(rightDir);
        // The commented out code is correct, but doesn't look right
        // Better to avoid parallel halls with only an edge-on wall
        // between them.
        if (true /* forwardWallP(rightx, righty, direction) */) {
          line(g, newh+newSize, newv, h+size, newv);
          line(g, newh+newSize, newv+newSize, h+size, newv+newSize);
        }
      }
      if (n > 1) {
        Vector cell = occupantCells[y][x];
        if (cell != null) {
          synchronized(cell) {
            int cnt = cell.size();
            for (int i=0; i<cnt; i++) {
              drawOccupant(g, (Physob)cell.elementAt(i), newh, newv, newSize);
            }
          }
        }
      }
      if (forwardp) {
        int left = newh;
        int right = newh+newSize;
        if (!newleftp) left = h;
        if (!newrightp) right = h + size;
        line(g, left, newv, right, newv);
        line(g, left, newv+newSize, right, newv+newSize);
        break;
      }
      x += dx;
      y += dy;
      n += 1;
      size = newSize;
      h = newh;
      v = newv;
    }
  }

  /**
   * Draw a line
   */
  public void line(Graphics g, int fromh, int fromv, int toh, int tov) {
    g.drawLine(fromh, fromv, toh, tov);
  }

  protected String notification;

  /**
   * Set the message displayed on the maze
   */
  public void notify(String message) {
    notification = message;
  }

  /**
   * Draw an occupant of the maze fitting in the sqaure with
   * its top-left corner at (h, v) and the given size.
   */
  public void drawOccupant(Graphics g, Physob occupant,
                           int h, int v, int size) {
    Drawing view;
    int odir = occupant.direction;
    Appearance ap = occupant.getAppearance();
    if (ap == null) return;
    if (direction == odir) view = ap.getBackView(occupant);
    else if (direction == leftDirection(odir)) view = ap.getRightView(occupant);
    else if (direction == rightDirection(odir)) view = ap.getLeftView(occupant);
    else view = ap.getFrontView(occupant);
    view.draw(g, h, v, size);
    String name = occupant.name;
    if (name != null) {
      if (occupant.ghost) name += " (ghost)";
      int wid = g.getFontMetrics().stringWidth(name);
      g.drawString(name, h + ((size - wid) / 2), v + size - 30);
    }
  }


  /**
   * Shoot a missile
   */
  public void shootMissile() {
    if (eye != null) eye.shootMissile();
  }

  /**
   * Move forward one square
   */
  public boolean moveForward() {
    if (eye != null) {
      eye.moveForward();
      return false;
    } else {
      return movePointForward(position, direction, true);
    }
  }

  /**
   * Move backward one square
   */
  public boolean moveBack() {
    if (eye != null) {
      eye.moveBack();
      return false;
    }
    else {
      return movePointBackward(position, direction);
    }
  }

  /**
   * Move a point by a delta in each direction
   */
  public void move(Point point, int dx, int dy) {
    int newx = point.x + dx;
    int newy = point.y + dy;
    if (newx < 1) newx = 1;
    if (newy < 1) newy = 1;
    if (newx > width) newx = width;
    if (newy > height) newy = height;
    point.x = newx;
    point.y = newy;
  }

  /**
   * Return the new x coordinate if moved in the given direction
   */
  public int movedX(int x, int direction) {
    int newx = x + deltaX(direction);
    if ((newx > 0) && (newx <= width)) return newx;
    return x;
  }

  /**
   * Return the new y coordinate if moved in the given direction
   */
  public int movedY(int y, int direction) {
    int newy = y + deltaY(direction);
    if ((newy > 0) && (newy <= width)) return newy;
    return y;
  }

  /**
   * Turn to the left
   */
  public void turnLeft() {
    if (eye != null) eye.turnLeft();
    else direction = leftDirection(direction);
  }

  /**
   * Turn to the right
   */
  public void turnRight() {
    if (eye != null) eye.turnRight();
    else direction = rightDirection(direction);
  }

  /* Stand up. Sit down. Fight, fight, fight */

  /**
   * Part of the KeyListener interface
   */
  public void keyTyped(KeyEvent e) {
  }

  /**
   * Part of the KeyListener interface
   */
  public void keyReleased(KeyEvent e) {
  }

  /**
   * Handle a keystroke. Part of the KeyListener interface.
   */
  public void keyPressed(KeyEvent e) {
    int code = e.getKeyCode();
    boolean repaint = true;
    if (code == KeyEvent.VK_RIGHT) {
      turnRight();
    } else if (code == KeyEvent.VK_LEFT) {
      turnLeft();
    } else if (code == KeyEvent.VK_UP) {
      repaint = moveForward();
    } else if (code == KeyEvent.VK_DOWN) {
      repaint = moveBack();
    } else repaint = false;
    if (code == KeyEvent.VK_SPACE) {
      shootMissile();
    }
    if (repaint) {
      Component c = paintComponent;
      if (c == null) c = (Component)e.getSource();
      c.repaint();
    }
  }

  public Component getPaintComponent() {
    return paintComponent;
  }

  public void setPaintComponent(Component c) {
    paintComponent = c;
  }

  /**
   * Add an occupant to the maze
   */
  public void addOccupant(Physob occupant) {
    occupant.maze = this;
    synchronized(occupants) {
      if (occupants.contains(occupant)) return;
      occupants.addElement(occupant);
    }
    addOccupantToCell(occupant);
    occupantChanged(occupant);
  }

  protected synchronized void addOccupantToCell(Physob occupant) {
    Point p = occupant.position;
    Vector v = occupantCells[p.y][p.x];
    if (v == null) occupantCells[p.y][p.x] = (v = new Vector());
    synchronized(v) {
      v.addElement(occupant);
    }
  }

  /**
   * Remove an occupant from the maze
   */
  public void removeOccupant(Physob occupant) {
    synchronized(occupants) {
      occupants.removeElement(occupant);
    }
    removeOccupantFromCell(occupant);
    occupantChanged(occupant);
  }

  protected void removeOccupantFromCell(Physob occupant) {
    Point p = occupant.position;
    Vector v = occupantCells[p.y][p.x];
    if (v != null) {
      synchronized(v) {
        v.removeElement(occupant);
      }
    }
  }

  /**
   * Return true if there is someone else in the same cell with you.
   * Missiles don't consider their owner to share the cell.
   * This prevents blowing yourself up.
   */
  public boolean isCellShared(Physob occupant) {
    Point p = occupant.position;
    Vector v = occupantCells[p.y][p.x];
    Physob owner = null;
    if (occupant instanceof Missile) {
      owner = ((Missile)occupant).getOwner();
    }
    for (int i=0; i<v.size(); i++) {
      Object o = v.elementAt(i);
      if ((o != occupant) && (o != owner)) return true;
    }
    return false;
  }

  /**
   * Return true if a cell is occupied
   */
  public boolean isCellOccupied(int x, int y) {
    Vector v = occupantCells[y][x];
    if (v == null) return false;
    return !v.isEmpty();
  }

  /**
   * Return an array of all the maze occupants
   */
  public Physob[] getAllOccupants(Physob[] res) {
    int size = occupants.size();
    if (size > res.length) res = new Physob[size];
    for (int i=0; i<size; i++) {
      res[i] = (Physob)occupants.elementAt(i);
    }
    for (int i=size; i<res.length; i++) {
      res[i] = null;
    }
    return res;
  }

  /**
   * Return an array of all the occupants of a cell
   */
  public Physob[] getOccupants(int x, int y) {
    Vector v = occupantCells[y][x];
    if (v == null) return new Physob[0];
    int cnt = v.size();
    Physob[] res = new Physob[cnt];
    for (int i=0; i<cnt; i++) {
      res[i] = (Physob)v.elementAt(i);
    }
    return res;
  }

  /**
   * Move an occupant to a new square.
   */
  public void moveOccupant(Physob occupant, int x, int y) {
    boolean couldSee = (occupant != eye) && canSee(eye, occupant);
    removeOccupantFromCell(occupant);
    Point p = occupant.position;
    p.x = x;
    p.y = y;
    addOccupantToCell(occupant);
    if (couldSee) repaint();
    else occupantChanged(occupant);
  }

  /**
   * Declare that the occupant has moved or turned.
   * Repaint if this matters to the eye.
   */
  public void occupantChanged(Physob occupant) {
    if ((occupant == eye) || canSee(eye, occupant)) repaint();
  }

  /**
   * Repaint the paintComponent, if there is one.
   */
  public void repaint() {
    if (paintComponent != null) paintComponent.repaint();
  }

  /**
   * Return true if an eye can see an occupant
   */
  public boolean canSee(Physob eye, Physob occupant) {
    if (eye == null) return false;
    Point pos = eye.position;
    Point opos = occupant.position;
    int x = pos.x;
    int y = pos.y;
    int ox = opos.x;
    int oy = opos.y;
    int dir = eye.direction;
    int dx = deltaX(dir);
    int dy = deltaY(dir);
    if ((dx == 0) && (x != ox)) return false;
    if ((dy == 0) && (y != oy)) return false;
    while ((x > 0) && (x <= width) && (y > 0) && (y <= height)) {
      if (forwardWallP(x, y, dir)) break;
      x += dx;
      y += dy;
      if ((x == ox) && (y == oy)) return true;
    }
    return false;
  }

  /**
   * Return true if the given eye can see a non-robot
   */
  public boolean canSeeNonRobot(Physob eye) {
    if (eye == null) return false;
    Point pos = eye.position;
    int x = pos.x;
    int y = pos.y;
    int dir = eye.direction;
    int dx = deltaX(dir);
    int dy = deltaY(dir);
    while ((x > 0) && (x <= width) && (y > 0) && (y <= height)) {
      if (forwardWallP(x, y, dir)) break;
      x += dx;
      y += dy;
      Vector v = occupantCells[y][x];
      if (v != null) {
        boolean nonEmpty = false;
        for (int i=0; i<v.size(); i++) {
          nonEmpty = true;
          if (!(v.elementAt(i) instanceof Robot)) return true;
        }
        // If the first cell we see is all robots, don't shoot.
        if (nonEmpty) return false;
      }
    }
    return false;
  }

  /**
   * Adds a guy to the maze so you can walk around and look at him.
   * Primarily for testing of the Physob drawing code.
   */
  public Physob addGuy(String name, int x, int y, int direction) {
    Physob guy = new Physob(name);
    guy.position.x = x;
    guy.position.y = y;
    guy.direction = direction;
    guy.appearance = SimpleAppearance.getHumanAppearance();
    addOccupant(guy);
    return guy;
  }


  /**
   * Add a robot to the maze
   */
  public Physob addRobot(String name, int x, int y, int direction,
                         Behavior behavior, boolean shooter) {
    Physob guy = new Robot(name);
    guy.position.x = x;
    guy.position.y = y;
    guy.direction = direction;
    guy.appearance = SimpleAppearance.getHumanAppearance();
    addOccupant(guy);
    if (behavior != null) guy.addBehavior(behavior);
    if (shooter) ShootWrapper.wrapBehavior(guy);
    return guy;
  }

  /**
   * Accessor for the engine property
   */
  public Engine getEngine() {
    return engine;
  }

  /**
   * Setter for the engine property
   */
  public void setEngine(Engine engine) {
    this.engine = engine;
  }

  /**
   * Accessor for the eye property
   */
  public Physob getEye() {
    return eye;
  }

  /**
   * Setter for the eye property
   */
  public void setEye(Physob eye) {
    this.eye = eye;
  }
  
  /**
   * Move an occupant to a random position and direction
   */
  public void randomize(Physob occupant) {
    int newx = randomInt(width-1) + 1;
    int newy = randomInt(height-1) + 1;
    int newDir = randomInt(4);
    occupant.direction = newDir;
    moveOccupant(occupant, newx, newy);
  }

  /**
   * Return a random integer >= 0 and < ceiling
   */
  public static int randomInt(int ceiling) {
    int res = (int)(Math.random() * ceiling);
    if ((res != 0) && (res == ceiling)) res--;
    return res;
  }

  /**
   * Add the eye, a drunk, and a wall hugger to the maze.
   */
  public void addTestGuys() {
    Physob eye = addGuy("You", 1, 1, RIGHT);
    setEye(eye);
    addRobot("Bob", 5, 1, RIGHT, new WallHugger(), true).ghost = true;
    addGuy("Joe", 6, 2, RIGHT).addBehavior(new Drunk(5));
    addRobot("Bill", 10, 10, UP, new Explorer(5), true);
  }

}
