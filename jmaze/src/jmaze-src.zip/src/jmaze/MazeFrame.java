/*
 * $Id: MazeFrame.java,v 1.4 2003/01/25 08:09:07 wws Exp $
 * A frame in which to draw the maze.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import javax.swing.JFrame;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Color;

public class MazeFrame extends JFrame {

  MazePanel panel;

  public MazeFrame() {
    this(new MazeModel(true));
  }

  public MazeFrame(MazeModel model) {
    super("Maze");
    model.addTestGuys();
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setBackground(Color.white);
    panel = new MazePanel(model);
    Container content = getContentPane();
    content.setLayout(new BorderLayout());
    content.add(panel, BorderLayout.CENTER);
    new Engine(model);
    addKeyListener(model);
  }

  public static void main(String[] args) {
    MazeFrame frame = new MazeFrame(new MazeModel(true));
    frame.pack();
    frame.setSize(500, 519);
    frame.show();
  }
} 
