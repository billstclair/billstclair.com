/*
 * $Id: Missile.java,v 1.1 2003/01/26 14:34:26 wws Exp $
 * A missile object.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import jmaze.robots.MissileBehavior;

public class Missile extends Physob {

  protected Physob owner;

  public Missile() {
  }

  public Missile(Physob owner) {
    super(computeName(owner));
    this.owner = owner;
    owner.setMissile(this);
    appearance = SimpleAppearance.getMissileAppearance();
    addBehavior(new MissileBehavior(owner));
  }

  public static String computeName(Physob owner) {
    String name = "" + owner.name;
    if (name.equalsIgnoreCase("you")) name = "your";
    else name += "'s";
    return name + " missile ";
  }

  public Physob getOwner() {
    return owner;
  }

  public Appearance getAppearance() {
    maybeInitializeAppearances();
    if (((position.x + position.y) % 2) == 0) return evenAppearance;
    else return oddAppearance;
  }

  protected static Appearance evenAppearance;
  protected static Appearance oddAppearance;

  protected static void maybeInitializeAppearances() {
    if (evenAppearance == null) {
      VectorDrawing rightView = new VectorDrawing
        (new int[][] {{200, 400, 750, 400, 750, 600, 200, 600, 200, 400,
                       200, 350, 300, 350, 300, 400},
                      {200, 600, 200, 650, 300, 650, 300, 600},
                      {750, 400, 850, 500, 750, 600},
                      {200, 475, 175, 475, 175, 525, 200, 525}});
      VectorDrawing leftView = rightView.mirror();
      evenAppearance = new SimpleAppearance
        (new VectorDrawing
         (new int[][] {{400, 400, 400, 600, 600, 600, 600, 400},
                       {400, 500, 600, 500},
                       {500, 400, 500, 600},
                       {400, 400, 365, 365},
                       {400, 600, 365, 635},
                       {600, 600, 635, 635},
                       {600, 400, 635, 365}}),
                       /*
                       {500, 400, 500, 350},
                       {500, 600, 500, 650},
                       {400, 500, 350, 500},
                       {600, 500, 650, 500}}),
                       */
         new VectorDrawing
         (new int[][] {{400, 400, 400, 600, 600, 600, 600, 400, 400, 400},
                       {475, 475, 475, 525, 525, 525, 525, 475, 475, 475},
                       {400, 400, 365, 365},
                       {400, 600, 365, 635},
                       {600, 600, 635, 635},
                       {600, 400, 635, 365}}),
                       /*
                       {500, 400, 500, 350},
                       {500, 600, 500, 650},
                       {400, 500, 350, 500},
                       {600, 500, 650, 500}}),
                       */
         leftView,
         rightView);
      oddAppearance = new SimpleAppearance
        (new VectorDrawing
         (new int[][] {{360, 500, 500, 360, 640, 500, 500, 640, 360, 500,
                        640, 500},
                       {500, 360, 500, 640},
                       {360, 500, 310, 500},
                       {500, 360, 500, 310},
                       {640, 500, 690, 500},
                       {500, 640, 500, 690}}),
                       /*
                       {430, 570, 395, 605},  // deltas of 70 and 35
                       {570, 570, 605, 605},
                       {430, 430, 395, 395},
                       {570, 430, 605, 395}}),
                       */
         new VectorDrawing
         (new int[][] {{360, 500, 500, 360, 640, 500, 500, 640, 360, 500},
                       {465, 500, 500, 535, 535, 500, 500, 465, 465, 500},
                       {360, 500, 310, 500},
                       {500, 360, 500, 310},
                       {640, 500, 690, 500},
                       {500, 640, 500, 690}}),
                       /*
                       {430, 570, 395, 605},  // deltas of 70 and 35
                       {570, 570, 605, 605},
                       {430, 430, 395, 395},
                       {570, 430, 605, 395}}),
                       */
         leftView,
         rightView);;
    }
  }
                         
  /* Testing code
   *
   * public static class HumanAppearancePanel extends javax.swing.JPanel {
   *   public void paint(java.awt.Graphics g) {
   *     Appearance ha = oddAppearance;
   *     ha.getFrontView(null).draw(g, 20, 20, 200);
   *     ha.getBackView(null).draw(g, 240, 20, 200);
   *     ha.getLeftView(null).draw(g, 20, 240, 200);
   *     ha.getRightView(null).draw(g, 240, 240, 200);
   *   }
   * }
   *
   * public static void main(String[] args) {
   *   maybeInitializeAppearances();
   *   javax.swing.JFrame frame = new javax.swing.JFrame("SimpleAppearance");
   *   frame.getContentPane().setLayout(new java.awt.BorderLayout());
   *   frame.getContentPane().add(new HumanAppearancePanel(),
   *                              java.awt.BorderLayout.CENTER);
   *   frame.pack();
   *   frame.setSize(460, 460);
   *   frame.show();
   * }
   */
}
