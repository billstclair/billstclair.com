/*
 * $Id: MazePanel.java,v 1.4 2003/01/25 21:23:31 wws Exp $
 * A Panel in which to draw a maze.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.awt.Point;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Panel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.Color;

public class MazePanel extends JPanel {
  protected MazeModel model;

  public MazePanel() {
    this(new MazeModel());
  }

  public MazePanel(MazeModel model) {
    this.model = model;
    model.setPaintComponent(this);
    setBackground(Color.white);
  }

  public void paint(Graphics g) {
    Dimension size = getSize();
    model.paint(g, size);
  }

  protected Runnable repainter = new Runnable() {
    public void run() {
      repaint();
    }
  };

  public void repaint() {
    if (SwingUtilities.isEventDispatchThread()) {
      Dimension size = getSize();
      paintImmediately(0, 0, size.width, size.height);
    } else if (repainter != null) {
      // Apparently, this method runs at startup before the
      // initializer for repainter is run.
      SwingUtilities.invokeLater(repainter);
    }
  }

  public MazeModel getModel() {
    return model;
  }
 
}
