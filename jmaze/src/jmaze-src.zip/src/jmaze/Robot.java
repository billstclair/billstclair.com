/*
 * $Id: Robot.java,v 1.1 2003/01/26 14:34:26 wws Exp $
 * A physical object that resides in the maze
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

/**
 * A robot.
 * This class exists only to make them easy to identify
 */
public class Robot extends Physob {

  public Robot() {
  }

  public Robot(String name) {
    super(name);
  }

}
