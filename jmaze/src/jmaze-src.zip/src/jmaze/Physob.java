/*
 * $Id: Physob.java,v 1.6 2003/01/26 16:18:49 wws Exp $
 * A physical object that resides in the maze
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.awt.Point;
import java.io.Serializable;
import jmaze.behavior.MoveForwardBehavior;
import jmaze.behavior.MoveBackBehavior;
import jmaze.behavior.TurnLeftBehavior;
import jmaze.behavior.TurnRightBehavior;
import jmaze.behavior.CombinedBehavior;
import jmaze.behavior.DieBehavior;
import jmaze.behavior.ShootMissileBehavior;

/**
 * A physical object in a maze.
 * Subclasses define robots, missiles, and other people.
 */
public class Physob implements Serializable {
  // My Name. Unique in all players.
  public String name;

  // The maze, position, and direction of this object
  public MazeModel maze;
  public Point position = new Point(0, 0);
  public int direction = MazeModel.RIGHT;

  // True if other players can move through you
  public boolean ghost = false;

  // True if a missile is in flight
  protected Missile missile;

  public Physob() {
    name = "noname";
  }

  public Physob(String name) {
    this.name = name;
  }

  // Drawings for the appearance from each of four sides
  protected Appearance appearance;

  // Determine behavior
  protected Behavior behavior;

  public Appearance getAppearance() {
    return appearance;
  }

  public void setAppearance(Appearance apperance) {
    this.appearance = appearance;
  }

  public Behavior getBehavior() {
    return behavior;
  }

  /**
   * Change my behavior.
   * You should usually use addBehavior()
   */
  public void setBehavior(Behavior behavior) {
    this.behavior = behavior;
  }

  public Missile getMissile() {
    return missile;
  }

  public void setMissile(Missile missile) {
    this.missile = missile;
  }

  public void moveForward() {
    addBehavior(MoveForwardBehavior.getInstance());
  }

  public void moveBack() {
    addBehavior(MoveBackBehavior.getInstance());
  }

  public void turnRight() {
    addBehavior(TurnRightBehavior.getInstance());
  }

  public void turnLeft() {
    addBehavior(TurnLeftBehavior.getInstance());
  }

  public void addBehavior(Behavior behavior) {
    if (this.behavior == null) this.behavior = behavior;
    else {
      this.behavior = CombinedBehavior.combine(this.behavior, behavior);
    }
  }

  /**
   * This object dies right now.
   */
  public void die() {
    if (this instanceof Missile) {
      maze.removeOccupant(this);
      ((Missile)this).getOwner().missile = null;
    }
    else maze.randomize(this);
  }

  /**
   * This object dies next tick, then resumes normal behavior.
   * A Behavior should never call die(), it should call kill()
   * to temporarily change the behavior to a DieBehavior.
   * The DieBehavior will return a DiaAction, which will call die()
   */
  public void kill(Physob killer) {
    String msg = (killer == null) ? "Killing " + name :
      killer.name + " shot " + name;
    msg += " at " + position.x + ", " + position.y;
    notify(msg);
    behavior = new DieBehavior(behavior);
  }

  public void notify(String message) {
    if (maze != null) maze.notify(message);
    else System.out.println(message);
  }

  /**
   * Shoot a missile
   */
  public void shootMissile() {
    behavior = new ShootMissileBehavior(behavior);
  }
}
