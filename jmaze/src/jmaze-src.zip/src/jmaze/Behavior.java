/*
 * $Id: Behavior.java,v 1.3 2003/01/25 21:23:31 wws Exp $
 * Define the behavior of a Physob in the maze
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import jmaze.behavior.MoveForwardAction;
import jmaze.behavior.MoveBackAction;
import jmaze.behavior.TurnLeftAction;
import jmaze.behavior.TurnRightAction;
import jmaze.behavior.DieAction;
import jmaze.behavior.ShootMissileAction;

import java.io.Serializable;

public interface Behavior extends Serializable {

  public Action doSomething(Physob ob);

  public static final Action FORWARD = MoveForwardAction.getInstance();
  public static final Action BACK = MoveBackAction.getInstance();
  public static final Action LEFT = TurnLeftAction.getInstance();
  public static final Action RIGHT = TurnRightAction.getInstance();
  public static final Action DIE = DieAction.getInstance();
  public static final Action SHOOT_MISSILE = ShootMissileAction.getInstance();

}
