/*
 * $Id: SimpleAppearance.java,v 1.2 2003/01/25 21:23:31 wws Exp $
 * An Appearance implementation that simply stores four Drawings.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

//import javax.swing.JFrame;
//import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.BorderLayout;

public class SimpleAppearance implements Appearance {

  protected Drawing frontView;
  protected Drawing backView;
  protected Drawing leftView;
  protected Drawing rightView;

  public SimpleAppearance() {
  }

  public SimpleAppearance(Drawing frontView, Drawing backView,
                          Drawing leftView, Drawing rightView) {
    this.frontView = frontView;
    this.backView = backView;
    this.leftView = leftView;
    this.rightView = rightView;
  }

  public Drawing getFrontView(Physob ob) {
    return frontView;
  }

  public Drawing getBackView(Physob ob) {
    return backView;
  }

  public Drawing getLeftView(Physob ob) {
    return leftView;
  }

  public Drawing getRightView(Physob ob) {
    return rightView;
  }

  protected static SimpleAppearance humanAppearance;

  /**
   * Make the default human appearance.
   */
  public static SimpleAppearance getHumanAppearance() {
    if (humanAppearance != null) return humanAppearance;
    VectorDrawing leftView =
      new VectorDrawing(new int[][] {{350, 100, 650, 100,
                                      650, 410, 350, 410, 350, 100},
                                     {350, 210, 300, 270, 350, 270},
                                     {480, 210, 520, 210,
                                      520, 250, 480, 290},
                                     {350, 350, 390, 350}});
    return (humanAppearance =
            new SimpleAppearance
            (new VectorDrawing(new int[][] {{250, 100, 750, 100,
                                             750, 410, 250, 410, 250, 100},
                                            {400, 200, 450, 200},
                                            {550, 200, 600, 200},
                                            {500, 210, 480, 270,
                                             520, 270, 500, 210},
                                            {460, 350, 540, 350}}),
            new VectorDrawing(new int[][] {{250, 100, 750, 100,
                                             750, 410, 250, 410, 250, 100}}),
            leftView, leftView.mirror()));
                                             
  }

  /**
   * Make the default missile appearance
   */
  public static Appearance getMissileAppearance() {
    return getHumanAppearance();
  }

  /* Commented out testing code so it will run without Swing
   *
   * public static class HumanAppearancePanel extends JPanel {
   *   public void paint(Graphics g) {
   *     Appearance ha = getHumanAppearance();
   *     ha.getFrontView(null).draw(g, 20, 20, 200);
   *     ha.getBackView(null).draw(g, 240, 20, 200);
   *     ha.getLeftView(null).draw(g, 20, 240, 200);
   *     ha.getRightView(null).draw(g, 240, 240, 200);
   *   }
   * }
   *
   * public static void main(String[] args) {
   *   javax.swing.JFrame frame = new JFrame("SimpleAppearance");
   *   frame.getContentPane().setLayout(new BorderLayout());
   *   frame.getContentPane().add(new HumanAppearancePanel(), BorderLayout.CENTER);
   *   frame.pack();
   *   frame.setSize(460, 460);
   *   frame.show();
   * }
   *
   */
}
