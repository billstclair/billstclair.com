/*
 * $Id: ShootMissileBehavior.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A Behavior that causes its object to die
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.util.Stack;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A Behavior that causes its object to die
 */
public class ShootMissileBehavior implements Behavior {

  protected Behavior regularBehavior;

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public ShootMissileBehavior() {
  }

  public ShootMissileBehavior(Behavior regularBehavior) {
    this.regularBehavior = regularBehavior;
  }

  public Action doSomething(Physob ob) {
    ob.addBehavior(regularBehavior);
    if (ob.getMissile() == null) return SHOOT_MISSILE;
    else return null;
  }
}
