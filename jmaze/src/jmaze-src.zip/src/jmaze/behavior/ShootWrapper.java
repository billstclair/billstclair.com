/*
 * $Id: ShootWrapper.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A BehaviorWrapper that shoots if it sees anybody.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A Behavior that wraps another behavior
 */
public class ShootWrapper extends BehaviorWrapper {

  protected Behavior wrappedBehavior;
  protected int cnt;

  /**
   * Constructor for serialziation.
   * Use the other constructor in code.
   */
  public ShootWrapper() {
  }

  public ShootWrapper(Behavior wrappedBehavior) {
    super(wrappedBehavior);
  }

  public static void wrapBehavior(Physob ob) {
    ob.setBehavior(new ShootWrapper(ob.getBehavior()));
  }

  /**
   * Shoot if we can see anybody, and our missile isn't already out there
   */
  public Action doSomething(Physob ob) {
    if (cnt > 0) {
      if (--cnt == 0) {
        ob.addBehavior(this);
        return SHOOT_MISSILE;
      }
    } else if ((ob.getMissile() == null) && ob.maze.canSeeNonRobot(ob)) {
      ob.addBehavior(this);
      cnt = 5;   // A half second delay to give some thinking time
      return null;
    }
    return super.doSomething(ob);
  }
}
