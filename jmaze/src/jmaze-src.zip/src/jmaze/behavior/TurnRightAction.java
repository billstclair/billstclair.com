/*
 * $Id: TurnRightAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Move a Physob forward one square
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.awt.Point;
import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that moves its Physob forward one square
 */
public class TurnRightAction extends Action {

  protected static TurnRightAction instance = new TurnRightAction();

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public TurnRightAction() {
  }

  public static TurnRightAction getInstance() {
    return instance;
  }

  public void act(Physob actor) {
    actor.direction = actor.maze.rightDirection(actor.direction);
    actor.maze.occupantChanged(actor);
  }

}
