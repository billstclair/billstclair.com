/*
 * $Id: ShootMissileAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Kill a physob
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Action;
import jmaze.Physob;
import jmaze.Missile;

/**
 * An Action that kills its Physob
 */
public class ShootMissileAction extends Action {

  protected static ShootMissileAction instance = new ShootMissileAction();

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public ShootMissileAction() {
  }

  public static ShootMissileAction getInstance() {
    return instance;
  }

  public void act(Physob owner) {
    Missile missile = new Missile(owner);
    missile.direction = owner.direction;
    missile.position.x = owner.position.x;
    missile.position.y = owner.position.y;
    missile.maze = owner.maze;
    owner.maze.addOccupant(missile);
  }

}
