/*
 * $Id: MoveBackAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Move a Physob backward one square
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.awt.Point;
import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that moves its Physob backward one square
 */
public class MoveBackAction extends Action {

  protected static MoveBackAction instance = new MoveBackAction();

  /**
   * Constructor for serialization only.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */

  public static MoveBackAction getInstance() {
    return instance;
  }

  protected Point point = new Point();

  public void act(Physob actor) {
    Point pos = actor.position;
    int x;
    int y;
    boolean moved = false;
    synchronized(point) {
      point.x = pos.x;
      point.y = pos.y;
      moved = actor.maze.movePointBackward(point, actor.direction);
      x = point.x;
      y = point.y;
    }
    if (moved) actor.maze.moveOccupant(actor, x, y);
  }

}
