/*
 * $Id: BehaviorWrapper.java,v 1.1 2003/01/26 14:34:26 wws Exp $
 * A behavior that wraps another behavior
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A Behavior that wraps another behavior
 */
public class BehaviorWrapper implements Behavior {

  protected Behavior wrappedBehavior;

  public BehaviorWrapper() {
  }

  public BehaviorWrapper(Behavior wrappedBehavior) {
    this.wrappedBehavior = wrappedBehavior;
  }

  /**
   * The normal behavior is to do what the wrapped behavior
   * wants and then restore the wrapper.
   * Subclasses will sometimes not call this normal method.
   * They'll do the wrapped behavior and reinstall the wrapper.
   * @see ShootingWrapper
   */
  public Action doSomething(Physob ob) {
    Action res = wrappedBehavior.doSomething(ob);
    wrappedBehavior = ob.getBehavior();
    ob.setBehavior(this);
    return res;
  }
}
