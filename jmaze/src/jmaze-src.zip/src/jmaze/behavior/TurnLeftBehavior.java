/*
 * $Id: TurnLeftBehavior.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A Behavior that moves forward one square
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A behavior that moves its Physob forward one square.
 */
public class TurnLeftBehavior implements Behavior {

  protected static TurnLeftBehavior instance = new TurnLeftBehavior();

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public TurnLeftBehavior() {
  }

  public static TurnLeftBehavior getInstance() {
    return instance;
  }

  public Action doSomething(Physob ob) {
    return TurnLeftAction.getInstance();
  }
}
