/*
 * $Id: CombinedBehavior.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A Behavior that combines other Behaviors
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.util.Stack;
import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A Behavior that combines other Behaviors
 */
public class CombinedBehavior implements Behavior {

  protected Behavior one;
  protected Behavior two;

  protected static Stack stack = new Stack();

  /**
   * Constructor for serialization only.
   * Use the combin method in code
   */
  public CombinedBehavior() {
  }

  public static Behavior combine(Behavior one, Behavior two) {
    if (one == null) return two;
    if (two == null) return one;
    CombinedBehavior res = null;
    synchronized(stack) {
      if (!stack.empty()) res = (CombinedBehavior)stack.pop();
      else res = new CombinedBehavior();
    }
    res.one = one;
    res.two = two;
    return res;
  }

  public Action doSomething(Physob ob) {
    Behavior one = this.one;
    Behavior two = this.two;
    this.one = null;
    this.two = null;
    synchronized(stack) {
      stack.push(this);
    }
    return CombinedAction.combine(one.doSomething(ob), two.doSomething(ob));
  }
}
