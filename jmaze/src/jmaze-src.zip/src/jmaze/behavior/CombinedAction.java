/*
 * $Id: CombinedAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * An Action that combines other Actions
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.util.Stack;
import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that combines other Actions
 */
public class CombinedAction extends Action {

  protected Action one;
  protected Action two;

  protected static Stack stack = new Stack();

  /**
   * Constructor for serialization only.
   * Use the combine() method to create one in code.
   */
  public CombinedAction() {
  }

  public static Action combine(Action one, Action two) {
    if (one == null) return two;
    if (two == null) return one;
    CombinedAction res = null;
    synchronized(stack) {
      if (!stack.empty()) res = (CombinedAction)stack.pop();
      else res = new CombinedAction();
    }
    res.one = one;
    res.two = two;
    return res;
  }

  public void act(Physob ob) {
    Action one = this.one;
    Action two = this.two;
    this.one = null;
    this.two = null;
    synchronized(stack) {
      stack.push(this);
    }
    one.act(ob);
    two.act(ob);
  }
}
