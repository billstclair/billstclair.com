/*
 * $Id: MoveForwardAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Move a Physob forward one square
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.awt.Point;
import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that moves its Physob forward one square
 */
public class MoveForwardAction extends Action {

  protected static MoveForwardAction instance = new MoveForwardAction();

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public MoveForwardAction() {
  }

  public static MoveForwardAction getInstance() {
    return instance;
  }

  protected Point point = new Point();

  public void act(Physob actor) {
    Point pos = actor.position;
    int x;
    int y;
    boolean moved = false;
    synchronized(point) {
      point.x = pos.x;
      point.y = pos.y;
      moved = actor.maze.movePointForward(point, actor.direction, actor.ghost);
      x = point.x;
      y = point.y;
    }
    if (moved) actor.maze.moveOccupant(actor, x, y);
  }

}
