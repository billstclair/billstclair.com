/*
 * $Id: DieAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Kill a physob
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that kills its Physob
 */
public class DieAction extends Action {

  protected static DieAction instance = new DieAction();

  /**
   * Constructor for serialization only.
   * Use the getInstance() method.
   * You only ever need that one instance of this class.
   */
  public DieAction() {
  }

  public static DieAction getInstance() {
    return instance;
  }

  public void act(Physob actor) {
    actor.die();
  }

}
