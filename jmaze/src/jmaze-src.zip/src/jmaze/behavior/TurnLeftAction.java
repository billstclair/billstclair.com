/*
 * $Id: TurnLeftAction.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * Move a Physob forward one square
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import java.awt.Point;
import jmaze.Action;
import jmaze.Physob;

/**
 * An Action that moves its Physob forward one square
 */
public class TurnLeftAction extends Action {

  protected static TurnLeftAction instance = new TurnLeftAction();

  /**
   * Constructor for serialziation.
   * Use the getInstance() method in code.
   * You only ever need that one instance of this class.
   */
  public TurnLeftAction() {
  }

  public static TurnLeftAction getInstance() {
    return instance;
  }

  public void act(Physob actor) {
    actor.direction = actor.maze.leftDirection(actor.direction);
    actor.maze.occupantChanged(actor);
  }

}
