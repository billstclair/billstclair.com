/*
 * $Id: PauseBehavior.java,v 1.1 2003/01/26 14:34:27 wws Exp $
 * A Behavior that delays another behavior
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze.behavior;

import jmaze.Behavior;
import jmaze.Action;
import jmaze.Physob;

/**
 * A behavior that delays another behavior
 */
public class PauseBehavior implements Behavior {

  protected int ticks;
  protected int cnt = 0;
  protected Behavior delayedBehavior;

  /**
   * Constructor for serialziation.
   * Use the other constructor in code.
   */
  public PauseBehavior() {
  }

  public PauseBehavior(int ticks, Behavior delayedBehavior) {
    this.ticks = ticks;
    this.delayedBehavior = delayedBehavior;
  }

  public Action doSomething(Physob ob) {
    if (++cnt >= ticks) {
      cnt = 0;
      if (delayedBehavior != null) ob.addBehavior(delayedBehavior);
    } else ob.addBehavior(this);
    return null;
  }
}
