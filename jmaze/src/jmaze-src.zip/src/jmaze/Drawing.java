/*
 * $Id: Drawing.java,v 1.1 2003/01/23 22:20:24 wws Exp $
 * An interface to draw a Phyob in the maze
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.awt.Graphics;
import java.io.Serializable;

public interface Drawing extends Serializable {

  /**
   * Draw me
   * @param g The graphics environment to use for drawing
   * @param h The horizontal component of the upper-left-hand corner
   * @param v The vertical component of the upper-left-hand corner
   * @param size The size of the square in which the drawing should
   *             be centered.
   */
  public void draw(Graphics g, int h, int v, int size);

}
