/*
 * $Id: Engine.java,v 1.1 2003/01/26 14:34:26 wws Exp $
 * The engine that runs the show.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.util.Vector;

public class Engine extends Thread {

  /**
   * Our maze
   */
  protected MazeModel maze;

  /**
   * Set true when someone asks us to quit
   */
  protected boolean quitRequest = false;

  /**
   * Milliseconds between runs of the thread
   */
  protected long period = 100;

  /**
   * The time we last started running the loop
   */
  protected long lastRun;

  /**
   * Start a thread to process activity for the given maze
   */
  public Engine(MazeModel maze) {
    this.maze = maze;
    maze.setEngine(this);
    start();
  }

  /**
   * The body of the processing thread.
   * Every "period" milliseconds, process the actions of all
   * the objects known to the maze.
   */
  public void run() {
    lastRun = System.currentTimeMillis();
    synchronized(this) {
      while(true) {
        long nextRun = lastRun + period;
        long delay = nextRun - System.currentTimeMillis();
        try {
          if (delay > 0) wait(delay);
        } catch (InterruptedException e) {}
        if (quitRequest) return;
        lastRun = System.currentTimeMillis();
        process();
      }
    }
  }

  public void quit() {
    // quit
    synchronized(this) {
      quitRequest = true;
      interrupt();
    }
  }

  protected Physob[] occupants = new Physob[100];

  public void process() {
    occupants = maze.getAllOccupants(occupants);
    for (int i=0; i<occupants.length; i++) {
      try {
        Physob ob = occupants[i];
        if (ob == null) break;
        Behavior behavior = ob.behavior;
        ob.behavior = null;
        if (behavior != null) {
          Action action = behavior.doSomething(ob);
          if (action != null) action.act(ob);
        }
      } catch (Exception e) {
        System.out.println("Engine error:");
        e.printStackTrace();
      }
    }
    processDeadOccupants();
  }

  protected void processDeadOccupants() {
    // Nothing to do yet. Nobody dies yet.
  }

}
