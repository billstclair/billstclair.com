/*
 * $Id: Action.java,v 1.1 2003/01/23 22:20:24 wws Exp $
 * A place to put the common actions returned by Behavior implementations
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.io.Serializable;

/**
 * An abstract class for representing an action by a physob.
 */
public abstract class Action implements Serializable {

  /**
   * The default action is to do nothing.
   * Subclasses should override this method
   * @param actor The actor
   */
  public void act(Physob actor) {
  }
}
