/*
 * $Id: VectorDrawing.java,v 1.2 2003/01/24 04:34:45 wws Exp $
 * The most common implementation of Drawing.
 *
 * Copyright 2003 by Bill St. Clair
 * bill@billstclair.com
 * All rights reserved.
 *
 */

package jmaze;

import java.awt.Graphics;

public class VectorDrawing implements Drawing {

  /**
   * An array of line segments.
   * Each segment is an array of alternating x & y values.
   * Each value is between 0 and SCALE - 1
   */
  protected int[][] segments;

  /**
   * The scale of the values in segments.
   * All values should be >= 0 and < SCALE
   */
  public static final int SCALE = 1000;

  /**
   * No-arg constructor for serialization
   */
  public VectorDrawing() {
  }

  /**
   * The constructor
   * @param segments The line segments for this drawing.
   *                 An array of alternating x & y values, each
   *                 of which is >= 0 and < SCALE
   */
  public VectorDrawing(int[][] segments) {
    this.segments = segments;
  }

  /**
   * Draw the segments. The Drawing interface.
   * @param g The graphics environment to use for drawing
   * @param h The horizontal component of the upper-left-hand corner
   * @param v The vertical component of the upper-left-hand corner
   * @param size The size of the square in which the drawing should
   *             be centered.
   */
  public void draw(Graphics g, int h, int v, int size) {
    for (int i=0; i<segments.length; i++) {
      int[] segment = segments[i];
      int x = convert(segment[0], size);
      int y = convert(segment[1], size);
      int maxidx = segment.length - 1;
      for (int j=2; j<maxidx; j+=2) {
        int tox = convert(segment[j], size);
        int toy = convert(segment[j+1], size);
        g.drawLine(h+x, v+y, h+tox, v+toy);
        x = tox;
        y = toy;
      }
    }
  }

  /**
   * Convert a value between 0 and SCALE to fit in the range of 0 to size
   * @param value The value to convert
   * @param the size to which to convert it
   */
  public int convert(int value, int size) {
    return (value * size) / SCALE;
  }

  /**
   * Return a mirror-image vector drawing to this one.
   * Used mostly to generate right images from left images.
   */
  public VectorDrawing mirror() {
    int len = segments.length;
    int[][] newsegs = new int[len][];
    for (int i=0; i<len; i++) {
      int[] seg = segments[i];
      int cnt = seg.length;
      int maxidx = cnt - 1;
      int[] newseg = new int[cnt];
      newsegs[i] = newseg;
      for (int j=0; j<maxidx; j+=2) {
        newseg[j] = SCALE - seg[j] - 1;
        newseg[j+1] = seg[j+1];
      }
    }
    return new VectorDrawing(newsegs);
  }

}
