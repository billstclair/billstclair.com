This folder contain the jmaze application.

jmaze is an attempt to reproduce the maze game I played during college
on the PDP-10/Imlac combination at the MIT Laboratory for Computer
Science.

All code is in the jmaze package. The main class is jmaze.jmaze.

To build:

  cd build
  jmaze

You may have to change the JAVA_HOME setting in jmaze.bat to point at
your JDK.
