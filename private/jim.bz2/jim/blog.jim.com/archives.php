
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  	  	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Type" content="text/html" />
    <title>Archives - Jim's blog</title>
    <meta name="description" content="Discussion of politics that matters - what republicans and democrats debate does not matter" />
    <meta name="keywords" content="liberty, libertarianism, libertarian, anarcho-capitalism, anarchy, capitalism, anarchocapitalism, cryptoanarchy, crypto-anarchy, war, politics, Ayn Rand, objectivism, moderate realism, socialism, catalonia, law, justice, natural rights" />
    <link rel="stylesheet" type="text/css" href="http://blog.jim.com/bblog/templates/lines/lines.css" />
				
		
</head>
<body>
<div id="banner">
    <h1><a href="http://blog.jim.com/">Jim's blog</a></h1>
      <span class="description">the point, however, is to change it.</span>
</div>
<div id="content">
      <div class="blog">


<h2 class="date">Apr 2006</h2><p>13<sup>th</sup>
 <a href="http://blog.jim.com/?postid=61">The threat of tracking phones</a> <br />
<h2 class="date">Mar 2006</h2><p>14<sup>th</sup>
 <a href="http://blog.jim.com/?postid=60">Ploughing the sea of Wickepedia.</a> <br />
<p>13<sup>th</sup>
 <a href="http://blog.jim.com/?postid=59">Google censors.</a> <br />
<h2 class="date">Feb 2006</h2><p>28<sup>th</sup>
 <a href="http://blog.jim.com/?postid=58">Indentity cards</a> <br />
<p>10<sup>th</sup>
 <a href="http://blog.jim.com/?postid=57">Jane Galt calls for higher taxes!</a> <br />
<p>09<sup>th</sup>
 <a href="http://blog.jim.com/?postid=56">Ping's proposal to fix phishing</a> <br />
<h2 class="date">Jan 2006</h2><p>31<sup>st</sup>
 <a href="http://blog.jim.com/?postid=55">Again return of the death of cypherpunks</a> <br />
<p>26<sup>th</sup>
 <a href="http://blog.jim.com/?postid=54">Hamas beats Bush</a> <br />
<p>13<sup>th</sup>
 <a href="http://blog.jim.com/?postid=53">PKI  written off</a> <br />
<p>01<sup>st</sup>
 <a href="http://blog.jim.com/?postid=52">Capital inflow to the US.</a> <br />
<h2 class="date">Dec 2005</h2><p>24<sup>th</sup>
 <a href="http://blog.jim.com/?postid=51">“Voodoo economics” works</a> <br />
<p>22<sup>nd</sup>
 <a href="http://blog.jim.com/?postid=49">The real character of those illegal wiretaps</a> <br />
<h2 class="date">Nov 2005</h2><p>23<sup>rd</sup>
 <a href="http://blog.jim.com/?postid=48">Fixing Phishing.</a> <br />
<h2 class="date">Oct 2005</h2><p>25<sup>th</sup>
 <a href="http://blog.jim.com/?postid=47">Two Thousand Dead</a> <br />
<p>23<sup>rd</sup>
 <a href="http://blog.jim.com/?postid=46">Economics in one lesson.</a> <br />
<p>02<sup>nd</sup>
 <a href="http://blog.jim.com/?postid=45">Time for civil war in Iraq</a> <br />
<h2 class="date">Sep 2005</h2><p>14<sup>th</sup>
 <a href="http://blog.jim.com/?postid=44">Government the disaster.</a> <br />
<p>04<sup>th</sup>
 <a href="http://blog.jim.com/?postid=43">USA at fault</a> <br />
<h2 class="date">Aug 2005</h2><p>24<sup>th</sup>
 <a href="http://blog.jim.com/?postid=42">Fans of terror.</a> <br />
<p>23<sup>rd</sup>
 <a href="http://blog.jim.com/?postid=41">No housing bubble</a> <br />
</div>
</div>
<div id="links">

<div class="sidetitle">Navigation</div>
<div class="side">
<a href="http://blog.jim.com/">Home</a><br /><a href="http://blog.jim.com/archives.php">Archives</a><br /><a href="http://blog.jim.com/rss.php?ver=2">RSS 2.0 Feed</a><br />
</div>

<div class="sidetitle">Recent Posts</div>
<div class="side">
<a href='http://blog.jim.com/?postid=61' title='The threat of tracking phones'>The threat of tracking phones</a><br /><a href='http://blog.jim.com/?postid=60' title='Ploughing the sea of Wickepedia.'>Ploughing the sea of...</a><br /><a href='http://blog.jim.com/?postid=59' title='Google censors.'>Google censors.</a><br /><a href='http://blog.jim.com/?postid=58' title='Indentity cards'>Indentity cards</a><br /><a href='http://blog.jim.com/?postid=57' title='Jane Galt calls for higher taxes!'>Jane Galt calls for higher...</a>
</div>

<div class="sidetitle">Sections</div>
<div class="side"><a href="http://blog.jim.com/?sectionid=5">News</a><br /><a href="http://blog.jim.com/?sectionid=1">News</a><br /><a href="http://blog.jim.com/?sectionid=3">Play</a><br /><a href="http://blog.jim.com/?sectionid=2">Work</a></div>

<!-- If you delete the powerered by bBlog link, support on the bBlog forum may be affected. So it's not a good idea.. -->
<div class="sidetitle">Props:</div>
<div class="side">
        Powered by<br /><a href="http://www.bblog.com">bBlog</a> the free PHP Blogging script.<br />
      </div>
    </div>

    <br clear="all" />


</body>
</html>
<!--//
This page took 0.05773 seconds to make
and executed 6 SQL queries.
Last modified: Thu, 11 May 2006 02:50:38 GMT
Powered by bBlog : http://www.bBlog.com/
//-->